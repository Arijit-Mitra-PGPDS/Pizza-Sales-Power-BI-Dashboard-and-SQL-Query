/* Total Revenue */

SELECT SUM(total_price) AS Total_Revenue FROM pizza_sales;

