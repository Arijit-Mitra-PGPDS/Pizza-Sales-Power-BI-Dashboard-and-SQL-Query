/* Total Pizzas Sold*/

SELECT SUM(quantity) AS Total_pizza_sold FROM pizza_sales